package com.example.Trippleback;

import org.springframework.data.jpa.repository.JpaRepository;

public interface JoinedCommunityRepository extends JpaRepository<Community, Long> {
}

