package com.example.Trippleback;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TripplebackApplication {

	public static void main(String[] args) {
		SpringApplication.run(TripplebackApplication.class, args);
	}

}
